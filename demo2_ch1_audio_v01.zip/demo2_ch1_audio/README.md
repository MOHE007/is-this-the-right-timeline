# Demo2 第一章音频素材交付 v0.1（程序合成母版）

依据 `demo2_ch1_audio_brief_v01.md` 生成。**P0 全部 16 项 + P1 全部 10 项已完成**，另附 UI 点击轻/重 2 个变体与远马蹄干声版，共 **29 个 WAV**。

## 规格符合性

| 项目 | 交付单要求 | 实际 |
|---|---|---|
| 采样/位深 | 48 kHz / 24-bit 立体声 WAV | ✅ 全部 PCM_24 / 48 kHz / 立体声 |
| 峰值 | ≤ -1 dBTP | ✅ 全部 ≤ -1 dBTP |
| BGM 响度起点 | 约 -18 LUFS | ✅ RMS -18.0 dB |
| 环境响度起点 | 约 -24 LUFS | ✅ RMS -24.0 dB |
| UI/SFX 响度起点 | -14 ~ -10 LUFS | ✅ 峰值 -9 ~ -15 dB（DSH 接入后统一调音） |
| 循环无缝 | 头尾可拼接、无长混响尾 | ✅ 全部做 wrap-crossfade（3–4 s），已验证首尾衔接 |
| SFX 尾巴 | 保留 100–300 ms 自然尾 | ✅ 未拖静音 |
| 命名 | 含 resource_id + 版本号 | ✅ `demo2_ch1_audio_<resource_id>_v01.wav` |

## 文件清单

### bgm/
| 文件（去前缀/后缀） | 时长 | 说明 |
|---|---|---|
| `AUD_BGM_INK_MAIN_01` | 63.7s | 72 BPM，D 羽调式，古琴拨弦+箫长音+低衬底，无鼓点。s04–s07 主探索 |
| `AUD_BGM_RECALL_TENSION_01` | 46.0s | 低频持续音（A1+Bb1 小二度张力）+极少闷击，克制不战斗。s08–s10 |
| `AUD_BGM_ENDING_QUIET_01` | 46.0s | D3/A3 呼吸衬底+稀疏单音+留白。s11–s13 |
| `AUD_BGM_XINQiji_ACTION_01`（P1） | 46.1s | 88 BPM，A 羽调式，太鼓式低点+拨弦音型，行动感不热血。s14 |

### ambience/
| 文件 | 时长 | 说明 |
|---|---|---|
| `AUD_AMB_INDOOR_PAPER_01` | 23.5s | 屋内底噪+窗纸风+纸张摩擦+远处极轻马蹄。s02/s05 |
| `AUD_AMB_FERRY_MIST_01` | 23.5s | 水流+水拍船板+船木轻响+绳索受力+薄雾风。s06 |
| `AUD_AMB_MILITARY_TOWN_01` | 23.5s | 旗面抖动+木栅吱呀+粮车低频+模糊人声层（无可辨台词）+远马呼吸。s07/s08 |

### sfx/
P0：`PAPER_TURN_01`、`INK_STAMP_01`、`UI_CLICK_INK`（中/`_light`/`_heavy` 三变体，主名兼容）、`CLUE_PICKUP_01`、`CLUE_VERIFY_01`、`TIMELINE_TICK_01`、`TIMELINE_JUMP_01`、`INK_SPREAD_01`、`ROUTE_CONNECT_01`、`UI_LOCKED_01`
P1：`HOOF_DISTANT_01`（+`_dry` 干声版）、`WATER_ROPE_01`、`HORSE_BREATH_01`、`FLAG_WIND_01`、`DISTANT_BELL_01`、`PAPER_RUSTLE_01`、`BRANCH_CONFIRM_01`、`SAVE_01`、`LOAD_01`

## 接入说明

1. 运行时接入：把 `bgm/`、`ambience/`、`sfx/` 三个目录的 WAV 复制到 `godot/demo2/assets/audio/` 对应目录，DSH 转 OGG 并登记 manifest 即可（BGM/AMB 用 loop 播放，转场淡入淡出）。
2. UI 点击三变体：随机/按交互权重挑选 `_light`（悬停/次要）、主文件（普通按钮）、`_heavy`（关键确认）。
3. 本套为程序合成母版（Karplus-Strong 拨弦、加性合成箫/钟、滤波噪声纹理），音色方向与规格已对齐；Logic Pro 重制版做好后**同名覆盖**即可，resource_id 不变。
4. 生成脚本在 `source_logic/generate_audio_assets.py`（Python 3.13 + numpy/scipy/soundfile，固定随机种子可复现）；`gen_manifest.tsv` 是机器可读清单（含时长/峰值/RMS）。
