# -*- coding: utf-8 -*-
"""
Demo2 第一章音频素材程序化生成器 v0.1
依据: demo2_ch1_audio_brief_v01.md
输出: 48 kHz / 24-bit 立体声 WAV, 峰值 <= -1 dBTP
BGM/AMB 均做头尾 wrap-crossfade 保证无缝循环; 一次性 SFX 保留自然短尾巴。
这些是可用的程序合成母版, Logic Pro 重制版可直接同名覆盖。
"""
import os
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfiltfilt

SR = 48000
rng = np.random.default_rng(20260914)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # demo2_ch1_audio/
OUT = {"bgm": os.path.join(ROOT, "bgm"),
       "amb": os.path.join(ROOT, "ambience"),
       "sfx": os.path.join(ROOT, "sfx")}
PREFIX = "demo2_ch1_audio_"

# ---------------------------------------------------------------- 基础工具

def T(dur):
    return np.arange(int(dur * SR)) / SR

def bp(x, lo, hi, order=4):
    sos = butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    return sosfiltfilt(sos, x)

def lp(x, hi, order=4):
    sos = butter(order, hi, btype="low", fs=SR, output="sos")
    return sosfiltfilt(sos, x)

def hp(x, lo, order=4):
    sos = butter(order, lo, btype="high", fs=SR, output="sos")
    return sosfiltfilt(sos, x)

def slow_lfo(dur, freqs, lo=0.0, hi=1.0):
    """几个正弦叠加的低频调制器, 端点平滑, 避免超低频数字滤波。"""
    t = T(dur)
    x = np.zeros_like(t)
    for f in freqs:
        x += np.sin(2 * np.pi * f * t + rng.uniform(0, 2 * np.pi))
    x = (x - x.min()) / (np.ptp(x) + 1e-12)
    return lo + x * (hi - lo)

def fade_env(n, a_s, r_s):
    """attack/release 线性包络, 保证首尾归零。"""
    e = np.ones(n)
    a = min(int(a_s * SR), n // 2)
    r = min(int(r_s * SR), n // 2)
    if a > 0:
        e[:a] *= np.linspace(0, 1, a)
    if r > 0:
        e[-r:] *= np.linspace(1, 0, r)
    return e

def wrap_xfade(x, fade_s):
    """把尾部 crossfade 进头部, 得到无缝循环 (长度减少 fade_s)。"""
    n = len(x)
    f = int(fade_s * SR)
    if f <= 0 or n <= 2 * f + 64:
        return x
    w = 0.5 - 0.5 * np.cos(np.linspace(0, np.pi, f))  # 0 -> 1
    out = x[: n - f].copy()
    out[:f] = x[n - f:] * (1 - w) + x[:f] * w
    return out

def stereo(x, width=0.0):
    l = x.copy()
    if width > 0:
        d = int(width * SR)
        r = np.concatenate([np.zeros(d), x[:-d]]) if d > 0 else x
        return np.stack([l, 0.85 * l + 0.35 * r], axis=1)
    return np.stack([l, l], axis=1)

def norm_peak_db(x, db):
    p = np.max(np.abs(x))
    if p < 1e-12:
        return x
    return x * (10 ** (db / 20) / p)

def clamp_peak_db(x, db):
    """只在超限时压低峰值 (真钳制, 不上抬)。"""
    p = np.max(np.abs(x))
    lim = 10 ** (db / 20)
    if p > lim:
        x = x * (lim / p)
    return x

def norm_rms_db(x, db):
    r = np.sqrt(np.mean(x ** 2))
    if r < 1e-12:
        return x
    y = x * (10 ** (db / 20) / r)
    return clamp_peak_db(y, -1.0)  # 峰值钳到 -1 dBTP

# ---------------------------------------------------------------- 音色原语

def pluck(f0, dur, damp=0.9965, bright=2600.0):
    """Karplus-Strong 拨弦, 近似古琴/古筝质感。"""
    n = int(dur * SR)
    N = max(2, int(SR / f0))
    buf = rng.uniform(-1, 1, N)
    buf = lp(buf, bright)
    out = np.empty(n)
    filled = 0
    while filled < n:
        m = min(N, n - filled)
        out[filled:filled + m] = buf[:m]
        buf = 0.5 * (buf + np.roll(buf, 1)) * damp
        filled += N
    out = lp(out, 4200)
    out *= np.exp(-T(dur) / (dur * 0.42)) * fade_env(n, 0.002, 0.05)
    return out

def flute(f0, dur, amp=1.0):
    """箫: 基音+气声, 慢起音带颤音。"""
    n = int(dur * SR)
    t = T(dur)
    vib = 1 + 0.004 * np.sin(2 * np.pi * 4.8 * t + rng.uniform(0, 6.28))
    ph = 2 * np.pi * f0 * np.cumsum(vib) / SR
    x = np.sin(ph) + 0.28 * np.sin(2 * ph) + 0.08 * np.sin(3 * ph)
    air = bp(rng.standard_normal(n), f0 * 1.5, f0 * 5.5) * 0.09
    e = np.minimum(t / 0.35, 1) * np.exp(-np.maximum(t - dur * 0.7, 0) / 0.4)
    e *= fade_env(n, 0.05, 0.15)
    return (x + air) * e * amp

def pad_drone(f0, dur, amp=1.0, air=0.0):
    n = int(dur * SR)
    t = T(dur)
    lfo = slow_lfo(dur, [0.05, 0.09], 0.7, 1.0)
    x = (np.sin(2 * np.pi * f0 * t) + 0.5 * np.sin(2 * np.pi * f0 * 2.001 * t)
         + 0.3 * np.sin(2 * np.pi * f0 * 2.997 * t))
    if air > 0:
        x = x + air * lp(rng.standard_normal(n), 700) * lfo
    return x * lfo * amp

def thump(f0=80, dur=0.8, drop=1.7, amp=1.0, click=0.3):
    n = int(dur * SR)
    t = T(dur)
    f = f0 * (drop * np.exp(-t / (dur * 0.22)) + 1 - np.exp(-t / (dur * 0.22)))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / (dur * 0.3))
    c = bp(rng.standard_normal(n), 700, 3200) * np.exp(-t / 0.012) * click
    return (x + c) * amp

def tap(freqs=(950, 1500, 2350), dur=0.35, amp=1.0, tau=0.055, click=0.5):
    n = int(dur * SR)
    t = T(dur)
    x = np.zeros(n)
    for f in freqs:
        x += np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) * np.exp(-t / (tau * 1000 / f))
    c = bp(rng.standard_normal(n), 1600, 6500) * np.exp(-t / 0.004) * click
    return (x + c) * amp * fade_env(n, 0.001, 0.02)

def paper_tex(dur, lo=900, hi=6500, amp=1.0, flutter=7.0, a=0.02, r=0.1):
    """纸张摩擦质感。"""
    n = int(dur * SR)
    x = bp(rng.standard_normal(n), lo, hi)
    flut = slow_lfo(dur, [flutter * 0.6, flutter, flutter * 1.7], 0, 1) ** 1.4
    x = x * flut
    return x * fade_env(n, a, r) * amp

def creak(dur=0.6, f0=350, amp=1.0):
    n = int(dur * SR)
    t = T(dur)
    f = f0 * (1 + 0.25 * np.sin(2 * np.pi * rng.uniform(2, 4.5) * t) + 0.15 * rng.standard_normal(n))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.5 + bp(rng.standard_normal(n), 220, 950) * 0.5
    e = np.sin(np.pi * np.minimum(t / dur, 1)) ** 0.8
    return x * e * amp

def breath(dur=1.2, f_lo=400, f_hi=1800, amp=1.0, trem=9.0):
    n = int(dur * SR)
    x = bp(rng.standard_normal(n), f_lo, f_hi)
    e = np.sin(np.pi * np.arange(n) / n) ** 1.5
    x = x * e * (0.75 + 0.25 * np.sin(2 * np.pi * trem * T(dur)))
    return x * amp

def shimmer(f0, dur, amp=1.0):
    t = T(dur)
    x = np.sin(2 * np.pi * f0 * t) + 0.4 * np.sin(2 * np.pi * f0 * 2.76 * t)
    return x * np.exp(-t / (dur * 0.35)) * fade_env(len(t), 0.01, 0.1) * amp

def whoosh(dur, f_lo=300, f_hi=2600, amp=1.0):
    """纸卷掠过: 高频带滑向低频带。"""
    n = int(dur * SR)
    t = T(dur) / dur
    hi = bp(rng.standard_normal(n), f_hi * 0.6, f_hi * 1.4)
    lo = bp(rng.standard_normal(n), f_lo * 0.7, f_lo * 1.6)
    x = hi * (1 - t) + lo * t
    e = np.sin(np.pi * t) ** 1.2
    return x * e * amp

def place(buf, snd, t0, amp=1.0):
    i = int(t0 * SR)
    j = min(i + len(snd), len(buf))
    if i < len(buf):
        buf[i:j] += snd[: j - i] * amp
    return buf

# ---------------------------------------------------------------- BGM

D_YU = [146.83, 174.61, 196.00, 220.00, 261.63, 293.66, 349.23, 392.00, 440.00, 523.25]  # D3..C5 羽调式
A_YU = [220.00, 261.63, 293.66, 329.63, 392.00, 440.00, 523.25]  # A3..C5

def bgm_ink_main():
    bpm, bars = 72, 20
    L = bars * 4 * 60 / bpm  # 66.67 s
    buf = np.zeros(int(L * SR))
    # 低音衬底
    place(buf, pad_drone(73.42, L, 0.16, air=0.10), 0)
    place(buf, pad_drone(110.0, L, 0.10), 0)
    # 古琴短句: 每两小节一句
    idx = 4  # 从 D4 附近开始游走
    for bar in range(0, bars, 2):
        if rng.uniform() < 0.18:
            continue
        for beat in [0, 1.5, 2.5]:
            if rng.uniform() < 0.45:
                continue
            idx = int(np.clip(idx + rng.integers(-2, 3), 0, len(D_YU) - 1))
            t0 = bar * 4 * 60 / bpm + beat * 60 / bpm
            dur = rng.uniform(2.0, 3.4)
            if t0 + dur > L - 0.5:
                continue
            place(buf, pluck(D_YU[idx], dur, damp=rng.uniform(0.995, 0.9975)), t0, rng.uniform(0.4, 0.6))
    # 箫长音
    place(buf, flute(440.0, 6.0, 0.30), 6 * 4 * 60 / bpm)
    place(buf, flute(293.66, 6.5, 0.28), 13 * 4 * 60 / bpm)
    # 高音微光
    for bar, f0 in [(4, 587.33), (11, 880.0), (17, 523.25)]:
        place(buf, shimmer(f0, 3.0, 0.05), bar * 4 * 60 / bpm)
    y = wrap_xfade(buf, 3.0)
    return norm_rms_db(stereo(y), -18)

def bgm_recall_tension():
    L = 50.0
    buf = np.zeros(int(L * SR))
    # 低频持续音 + 小二度张力
    place(buf, pad_drone(55.0, L, 0.40, air=0.06), 0)
    place(buf, pad_drone(58.27, L, 0.16), 0)
    place(buf, lp(rng.standard_normal(int(L * SR)), 500) * slow_lfo(L, [0.06, 0.17], 0.25, 1.0) * 0.10, 0)
    # 极少闷击
    for t0 in [6.0, 21.5, 37.0]:
        place(buf, lp(thump(58, 1.1, amp=1.0, click=0.05), 300), t0, 0.30)
    # 高频金属泛音若隐若现
    hi = np.sin(2 * np.pi * 1174.7 * T(L)) * slow_lfo(L, [0.11, 0.23], 0, 1) ** 2
    place(buf, hi * 0.02, 0)
    y = wrap_xfade(buf, 4.0)
    return norm_rms_db(stereo(y), -18)

def bgm_ending_quiet():
    L = 50.0
    buf = np.zeros(int(L * SR))
    place(buf, pad_drone(146.83, L, 0.22, air=0.14), 0)   # D3 呼吸衬底
    place(buf, pad_drone(220.0, L, 0.10), 0)             # A3
    place(buf, lp(rng.standard_normal(int(L * SR)), 600) * slow_lfo(L, [0.05, 0.13], 0.2, 1.0) * 0.06, 0)
    place(buf, pluck(293.66, 3.5, 0.996), 7.0, 0.35)     # 稀疏单音
    place(buf, pluck(261.63, 3.5, 0.996), 22.5, 0.30)
    place(buf, pluck(293.66, 3.5, 0.996), 40.0, 0.32)
    place(buf, shimmer(1174.7, 3.0, 0.03), 31.0)
    y = wrap_xfade(buf, 4.0)
    return norm_rms_db(stereo(y), -18)

def bgm_xinqiji_action():
    bpm, bars = 88, 18
    L = bars * 4 * 60 / bpm  # 49.09 s
    buf = np.zeros(int(L * SR))
    place(buf, pad_drone(110.0, L, 0.20, air=0.05), 0)
    spb = 60 / bpm
    for bar in range(bars):
        tb = bar * 4 * spb
        # 太鼓式低点: 克制, 不做战斗曲
        place(buf, lp(thump(62, 0.9, amp=1, click=0.08), 500), tb, 0.5)
        if bar % 2 == 0:
            place(buf, lp(thump(66, 0.7, click=0.05), 450), tb + 2.5 * spb, 0.3)
        else:
            place(buf, lp(thump(66, 0.7, click=0.05), 450), tb + 1.5 * spb, 0.28)
            place(buf, lp(thump(66, 0.7, click=0.05), 450), tb + 3.0 * spb, 0.22)
        # 木鱼质感点
        for b in [1.0, 3.0]:
            place(buf, tap((1250,), 0.14, tau=0.03, click=0.4), tb + b * spb, 0.14)
        # 拨弦固定音型
        pat = [0, 2, 3, 2] if bar % 2 == 0 else [1, 3, 4, 3]
        for k, deg in enumerate(pat):
            place(buf, pluck(A_YU[deg], 0.8, damp=0.9955), tb + k * 0.5 * spb, 0.30)
        if bar % 4 == 3:
            place(buf, pluck(A_YU[5], 1.6, damp=0.9965), tb + 2 * spb, 0.35)
    place(buf, flute(329.63, 5.0, 0.26), 8 * 4 * spb)
    y = wrap_xfade(buf, 3.0)
    return norm_rms_db(stereo(y), -18)

# ---------------------------------------------------------------- 环境声

def amb_indoor_paper():
    L = 26.0
    n = int(L * SR)
    buf = np.zeros(n)
    place(buf, lp(rng.standard_normal(n), 240) * 0.16, 0)              # 屋内底噪
    wind = bp(rng.standard_normal(n), 350, 1300) * slow_lfo(L, [0.07, 0.16, 0.31], 0.1, 1.0)
    place(buf, wind * 0.10, 0)                                          # 窗纸风
    for t0 in rng.uniform(1, L - 2, 7):                                 # 纸张摩擦
        place(buf, paper_tex(rng.uniform(0.3, 0.8), amp=1), float(t0), rng.uniform(0.05, 0.11))
    for t0 in [4.2, 17.8]:                                              # 远处极轻马蹄
        place(buf, lp(thump(75, 0.5, click=0.02), 220), t0, 0.10)
        place(buf, lp(thump(70, 0.5, click=0.02), 220), t0 + 0.22, 0.08)
    y = wrap_xfade(buf, 2.5)
    return norm_rms_db(stereo(y, 0.004), -24)

def amb_ferry_mist():
    L = 26.0
    n = int(L * SR)
    buf = np.zeros(n)
    flow = (lp(rng.standard_normal(n), 600) * 0.14
            + bp(rng.standard_normal(n), 900, 3000) * slow_lfo(L, [0.13, 0.29, 0.47], 0.15, 1.0) * 0.05)
    place(buf, flow, 0)                                                 # 水流
    for t0 in np.arange(1.5, L - 3, 4.1):                               # 水拍船板
        place(buf, bp(rng.standard_normal(int(1.6 * SR)), 280, 950)
              * fade_env(int(1.6 * SR), 0.4, 0.8), float(t0), 0.13)
    for t0 in [6.3, 15.1, 21.7]:                                        # 船木轻响
        place(buf, creak(rng.uniform(0.4, 0.7), rng.uniform(180, 330)), t0, 0.10)
    for t0 in [3.0, 12.4, 20.0]:                                        # 绳索受力
        d = 0.7
        r = bp(rng.standard_normal(int(d * SR)), 500, 2000)
        place(buf, r * fade_env(int(d * SR), 0.25, 0.25), t0, 0.07)
    mist = bp(rng.standard_normal(n), 1200, 4200) * slow_lfo(L, [0.05, 0.11], 0.2, 1.0)
    place(buf, mist * 0.05, 0)                                          # 薄雾风
    y = wrap_xfade(buf, 2.5)
    return norm_rms_db(stereo(y, 0.004), -24)

def amb_military_town():
    L = 26.0
    n = int(L * SR)
    buf = np.zeros(n)
    place(buf, lp(rng.standard_normal(n), 300) * 0.10, 0)               # 低频底
    flut = bp(rng.standard_normal(n), 800, 3200) * slow_lfo(L, [0.19, 0.41], 0, 1) ** 1.6
    flut *= (0.55 + 0.45 * np.sin(2 * np.pi * 11 * T(L)))               # 旗面抖动
    place(buf, flut * 0.08, 0)
    for t0 in [2.1, 9.8, 18.5, 23.4]:                                   # 木栅吱呀
        place(buf, creak(rng.uniform(0.4, 0.8), rng.uniform(150, 280)), t0, 0.09)
    place(buf, lp(rng.standard_normal(n), 130) * slow_lfo(L, [0.08, 0.2], 0.3, 1.0) * 0.10, 0)  # 粮车低频滚动
    mur = bp(rng.standard_normal(n), 300, 850) * slow_lfo(L, [2.9, 4.3, 5.4], 0, 1) ** 2  # 模糊人声层
    place(buf, mur * lp(np.ones(n), 900) * 0.045, 0)
    for t0 in [7.5, 19.0]:                                              # 远处马匹呼吸
        place(buf, lp(breath(1.3, 300, 1200), 1000), t0, 0.05)
    y = wrap_xfade(buf, 2.5)
    return norm_rms_db(stereo(y, 0.004), -24)

# ---------------------------------------------------------------- SFX

def sfx_paper_turn():
    buf = np.zeros(int(1.05 * SR))
    place(buf, whoosh(0.55, 400, 3400), 0.05, 0.8)
    place(buf, paper_tex(0.35, 1200, 7000, flutter=9), 0.55, 0.6)       # 翻页落定
    place(buf, paper_tex(0.15, 2500, 8000, flutter=14), 0.82, 0.35)
    return norm_peak_db(stereo(buf), -12)

def sfx_ink_stamp(deep=90):
    buf = np.zeros(int(1.5 * SR))
    place(buf, thump(deep, 0.5, drop=2.2, click=0.5), 0, 0.9)
    place(buf, paper_tex(0.5, 250, 1600, flutter=5, a=0.01, r=0.3), 0.12, 0.5)  # 墨水润纸
    place(buf, lp(rng.standard_normal(int(0.8 * SR)), 900)
          * fade_env(int(0.8 * SR), 0.15, 0.5), 0.25, 0.12)
    return norm_peak_db(stereo(buf), -12)

def sfx_ui_click(size="medium"):
    dur = {"light": 0.18, "medium": 0.24, "heavy": 0.32}[size]
    f0 = {"light": 1150, "medium": 950, "heavy": 720}[size]
    amp = {"light": 0.75, "medium": 1.0, "heavy": 1.25}[size]
    buf = np.zeros(int(dur * SR) + int(0.05 * SR))
    place(buf, tap((f0, f0 * 1.62), dur, tau=0.035, click=0.45), 0, amp)
    place(buf, paper_tex(0.12, 2000, 7000, flutter=12, a=0.005, r=0.06), 0.01, 0.25)
    gain = {"light": 0.7, "medium": 1.0, "heavy": 1.4}[size]  # 变体保留响度差
    return clamp_peak_db(norm_peak_db(stereo(buf), -12) * gain, -1.0)

def sfx_clue_pickup():
    buf = np.zeros(int(0.85 * SR))
    place(buf, paper_tex(0.28, 1000, 6000, flutter=8), 0, 0.7)
    place(buf, paper_tex(0.3, 700, 4500, flutter=6), 0.22, 0.55)
    place(buf, tap((880, 1320), 0.25, tau=0.05, click=0.3), 0.42, 0.30)  # 轻木质点音
    return norm_peak_db(stereo(buf), -12)

def sfx_clue_verify():
    buf = np.zeros(int(1.2 * SR))
    place(buf, thump(110, 0.4, drop=1.8, click=0.35), 0, 0.55)
    place(buf, paper_tex(0.3, 300, 1800, flutter=5), 0.08, 0.3)
    place(buf, shimmer(1568.0, 0.8, 0.5), 0.25, 0.22)                    # 短泛音
    place(buf, shimmer(3136.0, 0.5, 0.4), 0.27, 0.08)
    return norm_peak_db(stereo(buf), -12)

def sfx_timeline_tick():
    buf = np.zeros(int(0.6 * SR))
    place(buf, tap((1800, 2450, 3200), 0.4, tau=0.045, click=0.55), 0, 0.8)  # 玉片轻敲
    place(buf, tap((1200,), 0.2, tau=0.03, click=0.3), 0.01, 0.35)
    return norm_peak_db(stereo(buf), -12)

def sfx_timeline_jump():
    buf = np.zeros(int(1.4 * SR))
    place(buf, whoosh(1.0, 250, 2800), 0.1, 0.7)                         # 纸卷掠过
    wind = lp(rng.standard_normal(int(1.4 * SR)), 400) * fade_env(int(1.4 * SR), 0.35, 0.45)
    place(buf, wind, 0, 0.35)                                            # 低风层
    place(buf, paper_tex(0.25, 900, 5000, flutter=9), 1.0, 0.3)
    return norm_peak_db(stereo(buf), -12)

def sfx_ink_spread():
    dur = 1.7
    n = int(dur * SR)
    t = T(dur)
    wet = bp(rng.standard_normal(n), 160, 1100, order=3)
    bub = 0.6 + 0.4 * slow_lfo(dur, [5.5, 8.3, 11.7], 0, 1)              # 湿墨气泡感
    e = np.clip(t / 0.4, 0, 1) * np.exp(-np.maximum(t - 1.1, 0) / 0.25)
    buf = wet * bub * e
    place(buf, paper_tex(0.12, 300, 1500, flutter=6, a=0.01, r=0.06), 1.25, 0.5)  # 分叉感
    place(buf, paper_tex(0.12, 400, 1800, flutter=7, a=0.01, r=0.06), 1.38, 0.4)
    return norm_peak_db(stereo(buf), -12)

def sfx_route_connect():
    buf = np.zeros(int(0.75 * SR))
    n1 = int(0.3 * SR)
    f = np.linspace(420, 940, n1)                                        # 细线拉紧
    place(buf, np.sin(2 * np.pi * np.cumsum(f) / SR) * fade_env(n1, 0.02, 0.1), 0, 0.4)
    place(buf, bp(rng.standard_normal(n1), 600, 2500) * fade_env(n1, 0.02, 0.1), 0, 0.25)
    place(buf, shimmer(2350.0, 0.35, 0.5), 0.3, 0.16)                    # 纸面点亮
    return norm_peak_db(stereo(buf), -12)

def sfx_ui_locked():
    buf = np.zeros(int(0.42 * SR))
    place(buf, lp(bp(rng.standard_normal(int(0.2 * SR)), 150, 420), 500)
          * fade_env(int(0.2 * SR), 0.005, 0.1), 0, 0.9)                 # 闷纸声
    place(buf, tap((420, 650), 0.18, tau=0.04, click=0.2), 0, 0.5)       # 木片轻碰
    return norm_peak_db(stereo(buf), -12)

# ---------------------------------------------------------------- P1

def p1_hoof_distant(dry=False):
    buf = np.zeros(int(4.5 * SR))
    for k in range(4):
        t0 = 0.3 + k * 0.9
        place(buf, thump(88, 0.35, drop=1.5, click=0.1), t0, 0.55)
        place(buf, thump(80, 0.35, drop=1.5, click=0.08), t0 + 0.16, 0.42)
    y = buf if dry else lp(buf, 900) + 0.35 * np.roll(lp(buf, 900), int(0.11 * SR)) \
        + 0.18 * np.roll(lp(buf, 900), int(0.24 * SR))
    y = y[: int(4.5 * SR)] * fade_env(len(buf), 0.05, 0.4)
    return norm_peak_db(stereo(y), -14)

def p1_water_rope():
    buf = np.zeros(int(4.0 * SR))
    n = len(buf)
    place(buf, lp(rng.standard_normal(n), 800) * 0.12, 0)
    for t0 in [0.4, 1.6, 2.7, 3.4]:
        d = 1.1
        place(buf, bp(rng.standard_normal(int(d * SR)), 300, 1000) * fade_env(int(d * SR), 0.3, 0.6), t0, 0.35)
    for t0 in [1.0, 2.9]:
        d = 0.8
        place(buf, bp(rng.standard_normal(int(d * SR)), 500, 2200) * fade_env(int(d * SR), 0.3, 0.3), t0, 0.22)
    place(buf, creak(0.5, 240), 2.1, 0.3)
    return norm_peak_db(stereo(buf), -13)

def p1_horse_breath():
    buf = np.zeros(int(3.2 * SR))
    place(buf, breath(1.1, 400, 1700), 0.3, 0.8)
    place(buf, breath(1.3, 380, 1600, trem=7), 1.7, 0.65)
    return norm_peak_db(stereo(buf), -13)

def p1_flag_wind():
    buf = np.zeros(int(4.0 * SR))
    n = len(buf)
    place(buf, bp(rng.standard_normal(n), 200, 900) * slow_lfo(4.0, [0.13, 0.3], 0.2, 1.0) * 0.25, 0)
    for t0 in [0.2, 1.5, 2.6]:
        d = 1.0
        x = bp(rng.standard_normal(int(d * SR)), 800, 3500)
        x *= (0.5 + 0.5 * np.sin(2 * np.pi * 11 * T(d))) * slow_lfo(d, [3.0, 6.0], 0.1, 1.0)
        place(buf, x, t0, 0.4)
    return norm_peak_db(stereo(buf), -14)

def p1_distant_bell():
    dur = 4.8
    n = int(dur * SR)
    t = T(dur)
    buf = np.zeros(n)
    f0 = 196.0
    for m, a, tau in [(1, 1.0, 2.2), (2.02, 0.5, 1.5), (2.94, 0.32, 1.0), (4.06, 0.2, 0.7), (5.45, 0.1, 0.45)]:
        buf += np.sin(2 * np.pi * f0 * m * t + rng.uniform(0, 6.28)) * np.exp(-t / tau) * a
    buf = lp(buf, 1800) * 0.5
    place(buf, bp(rng.standard_normal(int(0.1 * SR)), 500, 2500)
          * np.exp(-T(0.1) / 0.02), 0, 0.3)                              # 击钟瞬态
    buf *= fade_env(n, 0.005, 0.8)
    return norm_peak_db(stereo(buf), -13)

def p1_paper_rustle():
    buf = np.zeros(int(3.0 * SR))
    for t0, d, a in [(0.1, 0.6, 0.6), (0.9, 0.4, 0.4), (1.5, 0.8, 0.7), (2.4, 0.5, 0.45)]:
        place(buf, paper_tex(d, 800, 7000, flutter=rng.uniform(5, 10)), t0, a)
    return norm_peak_db(stereo(buf), -13)

def p1_branch_confirm():
    buf = np.zeros(int(1.1 * SR))
    place(buf, thump(72, 0.55, drop=2.0, click=0.4), 0, 0.8)
    place(buf, paper_tex(0.4, 250, 1500, flutter=4.5), 0.1, 0.45)
    place(buf, shimmer(1046.5, 0.6, 0.5), 0.3, 0.18)
    place(buf, paper_tex(0.1, 350, 1600, flutter=6, a=0.01, r=0.05), 0.62, 0.4)  # 双分支
    place(buf, paper_tex(0.1, 420, 1800, flutter=7, a=0.01, r=0.05), 0.76, 0.32)
    return norm_peak_db(stereo(buf), -12)

def p1_save():
    buf = np.zeros(int(0.75 * SR))
    place(buf, thump(105, 0.35, drop=1.7, click=0.3), 0, 0.6)
    place(buf, paper_tex(0.25, 400, 2200, flutter=6), 0.1, 0.3)
    place(buf, tap((1450,), 0.2, tau=0.04, click=0.3), 0.3, 0.2)
    return norm_peak_db(stereo(buf), -12)

def p1_load():
    buf = np.zeros(int(0.75 * SR))
    place(buf, paper_tex(0.3, 900, 5500, flutter=8), 0, 0.7)             # 纸页展开
    place(buf, whoosh(0.25, 600, 3000), 0.12, 0.4)
    place(buf, tap((1100,), 0.18, tau=0.035, click=0.25), 0.42, 0.25)
    return norm_peak_db(stereo(buf), -12)

# ---------------------------------------------------------------- 主流程

ASSETS = [
    # (分类, resource_id, 生成函数, 备注)
    ("bgm", "AUD_BGM_INK_MAIN_01", bgm_ink_main, "P0 BGM 66.7s@72BPM 古琴/箫/衬底, 无鼓点"),
    ("bgm", "AUD_BGM_RECALL_TENSION_01", bgm_recall_tension, "P0 BGM 50s 低频持续音+极少闷击"),
    ("bgm", "AUD_BGM_ENDING_QUIET_01", bgm_ending_quiet, "P0 BGM 50s 留白低密度"),
    ("bgm", "AUD_BGM_XINQiji_ACTION_01", bgm_xinqiji_action, "P1 BGM 49.1s@88BPM 行动感"),
    ("amb", "AUD_AMB_INDOOR_PAPER_01", amb_indoor_paper, "P0 环境 26s 屋内/窗纸风/纸摩擦/远马蹄"),
    ("amb", "AUD_AMB_FERRY_MIST_01", amb_ferry_mist, "P0 环境 26s 水流/船木/绳索/薄雾风"),
    ("amb", "AUD_AMB_MILITARY_TOWN_01", amb_military_town, "P0 环境 26s 旗面/木栅/粮车/模糊人声"),
    ("sfx", "AUD_SFX_PAPER_TURN_01", sfx_paper_turn, "P0 翻页 1.05s"),
    ("sfx", "AUD_SFX_INK_STAMP_01", sfx_ink_stamp, "P0 印章落纸+墨扩散 1.5s"),
    ("sfx", "AUD_SFX_UI_CLICK_INK", lambda: sfx_ui_click("medium"), "P0 UI点击·中"),
    ("sfx", "AUD_SFX_UI_CLICK_INK_light", lambda: sfx_ui_click("light"), "P0 UI点击·轻变体"),
    ("sfx", "AUD_SFX_UI_CLICK_INK_heavy", lambda: sfx_ui_click("heavy"), "P0 UI点击·重变体"),
    ("sfx", "AUD_SFX_CLUE_PICKUP_01", sfx_clue_pickup, "P0 线索拾取 0.85s"),
    ("sfx", "AUD_SFX_CLUE_VERIFY_01", sfx_clue_verify, "P0 验证成功 1.2s"),
    ("sfx", "AUD_SFX_TIMELINE_TICK_01", sfx_timeline_tick, "P0 年份节点聚焦 0.6s"),
    ("sfx", "AUD_SFX_TIMELINE_JUMP_01", sfx_timeline_jump, "P0 时间线跳转 1.4s"),
    ("sfx", "AUD_SFX_INK_SPREAD_01", sfx_ink_spread, "P0 墨扩散/分叉 1.7s"),
    ("sfx", "AUD_SFX_ROUTE_CONNECT_01", sfx_route_connect, "P0 槽位连通 0.75s"),
    ("sfx", "AUD_SFX_UI_LOCKED_01", sfx_ui_locked, "P0 锁定反馈 0.42s"),
    ("sfx", "AUD_SFX_HOOF_DISTANT_01", p1_hoof_distant, "P1 远马蹄(带空间感)"),
    ("sfx", "AUD_SFX_HOOF_DISTANT_01_dry", lambda: p1_hoof_distant(dry=True), "P1 远马蹄(干声版)"),
    ("sfx", "AUD_SFX_WATER_ROPE_01", p1_water_rope, "P1 水拍船板+绳索"),
    ("sfx", "AUD_SFX_HORSE_BREATH_01", p1_horse_breath, "P1 马匹呼吸"),
    ("sfx", "AUD_SFX_FLAG_WIND_01", p1_flag_wind, "P1 旗面抖动+空风"),
    ("sfx", "AUD_SFX_DISTANT_BELL_01", p1_distant_bell, "P1 远钟单响"),
    ("sfx", "AUD_SFX_PAPER_RUSTLE_01", p1_paper_rustle, "P1 多层纸张摩擦"),
    ("sfx", "AUD_SFX_BRANCH_CONFIRM_01", p1_branch_confirm, "P1 结局分支确认"),
    ("sfx", "AUD_SFX_SAVE_01", p1_save, "P1 存档"),
    ("sfx", "AUD_SFX_LOAD_01", p1_load, "P1 读档"),
]

def main():
    rows = []
    for cat, rid, fn, note in ASSETS:
        y = fn()
        name = f"{PREFIX}{rid}_v01.wav"
        path = os.path.join(OUT[cat], name)
        sf.write(path, y.astype(np.float64), SR, subtype="PCM_24")
        dur = len(y) / SR
        peak = 20 * np.log10(max(np.max(np.abs(y)), 1e-12))
        rms = 20 * np.log10(max(np.sqrt(np.mean(y ** 2)), 1e-12))
        rows.append((cat, rid, name, dur, peak, rms, note))
        print(f"[{cat:3s}] {name:58s} {dur:6.2f}s  peak {peak:6.1f} dB  rms {rms:6.1f} dB")
    print(f"\n共 {len(rows)} 个文件")
    with open(os.path.join(ROOT, "gen_manifest.tsv"), "w") as f:
        f.write("category\tresource_id\tfile\tduration_s\tpeak_db\trms_db\tnote\n")
        for r in rows:
            f.write("\t".join(str(x) for x in r) + "\n")

if __name__ == "__main__":
    main()
